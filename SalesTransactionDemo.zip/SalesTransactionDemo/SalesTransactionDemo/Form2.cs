﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesTransactionDemo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

       

        private List<SalesTransaction> sales = new List<SalesTransaction>();
       
        private void Form2_Load(object sender, EventArgs e)
        {
            sales.Add(new SalesTransaction("Ali", 2000.77m, 0.20));
            sales.Add(new SalesTransaction("Wali", 3178.77m, 0.30));
            sales.Add(new SalesTransaction("Yahya", 1640.77m, 0.40));
            sales.Add(new SalesTransaction("Mike", 2225.77m, 0.50));
            sales.Add(new SalesTransaction("Tike", 4290.77m, 0.20));

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var filtered =
                from name in sales
                where name.Amount > 2000
                select name;
            foreach(var y in filtered)
            {
                richTextBox1.AppendText(y.ToString());
                
            }
            
        }
    }
}
