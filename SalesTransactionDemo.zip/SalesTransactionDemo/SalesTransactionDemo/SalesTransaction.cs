﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTransactionDemo
{
    class SalesTransaction
    {
        public string Name { get; private set; }
        public decimal Amount { get; private set; }
        public decimal Commission { get; private set; }

        private double commissionRate;

        public double CommissionRate
        {
            get { return commissionRate; }
            set {
                if(value<0 || value >= 1)
                {
                    throw new ArgumentOutOfRangeException
                        ("Invalid commission rate");
                }
                else { commissionRate = value; }
                 }
        }


        public SalesTransaction(string name, decimal amount, double rate)
        {
            Name = name;
            Amount = amount;
            CommissionRate = rate;
            Commission = Convert.ToDecimal(CommissionRate) * Amount;
        }
        public SalesTransaction(string name, decimal amount)
        {
            commissionRate = 0.0;
            Name = name;
            Amount = amount;
        }

        public SalesTransaction(string name)
        {
            Name = name;
            CommissionRate = 0;
            Amount = 0;
            Commission = 0;

        }

        public override string ToString()
        {
            return string.Format(" \nName:{0,-10} Amount: {1,-10:C}" +
                " Commission: {2,-10:C}  Commission Rate:{3,6}",
               Name, Amount, Commission, CommissionRate);
        }

    }
}
